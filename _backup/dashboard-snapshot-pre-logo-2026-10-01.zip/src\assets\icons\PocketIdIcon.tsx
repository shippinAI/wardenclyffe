import { iconProperties, IconProps } from "@/assets/icons/IconProperties";

export default function PocketIdIcon(props: Readonly<IconProps>) {
  return (
    <svg
      viewBox="0 0 512 512"
      xmlns="http://www.w3.org/2000/svg"
      {...iconProperties(props)}
    >
      <circle cx="256" cy="256" r="256" fill="#fff" />
      <path
        d="M268.6 102.4c64.4 0 116.8 52.4 116.8 116.7 0 25.3-8 49.4-23 69.6-14.8 19.9-35 34.3-58.4 41.7l-6.5 2-15.5-76.2 4.3-2c14-6.7 23-21.1 23-36.6 0-22.4-18.2-40.6-40.6-40.6S228 195.2 228 217.6c0 15.5 9 29.8 23 36.6l4.2 2-25 153.4h-69.5V102.4z"
        fill="#191919"
      />
    </svg>
  );
}