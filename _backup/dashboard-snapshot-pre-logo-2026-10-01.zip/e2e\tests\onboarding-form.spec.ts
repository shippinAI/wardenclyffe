/**
 * Onboarding form selection spec.
 *
 * Validates which onboarding form is shown first and which one persists,
 * across signup-source and account states — the recurring "regular form
 * flashes before the Agent Network form" bug. Onboarding is disabled in the
 * test build by default; each test opts in via the `wardenclyffe-test-onboarding`
 * localStorage flag (see testOnboardingEnabled in src/utils/wardenclyffe.ts), and
 * GET /accounts is rewritten to drive the account's onboarding + settings
 * state (same interception approach as edition-gating.spec.ts).
 */
import { test, expect, type Browser, type Page } from "@playwright/test";
import { loginToApp } from "../helpers/auth";

const SIGNUP_SOURCE_KEY = "wardenclyffe-signup-source";
const AGENT_NETWORK_SOURCE = "wardenclyffe.ai";

const AGENT_FORM = "agent-network-onboarding";
const REGULAR_FORM = "regular-onboarding";

type AccountState = {
  signupFormPending?: boolean;
  onboardingFlowPending?: boolean;
  agentNetworkOnly?: boolean;
};

// mockAccounts rewrites GET /accounts to drive the onboarding + focused-view
// state, optionally delaying the response to emulate a slow backend. A PUT to
// /accounts/{id} flips agent_network_only to true afterwards, mirroring the
// server persisting the wardenclyffe.ai signup mark.
function mockAccounts(page: Page, state: AccountState, delayMs: number) {
  let agentNetworkOnly = state.agentNetworkOnly;

  page.route("**/api/accounts", async (route) => {
    if (route.request().method() !== "GET") return route.continue();
    if (delayMs > 0) {
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
    const response = await route.fetch();
    let body: any;
    try {
      body = await response.json();
    } catch (e) {
      return route.fulfill({ response });
    }
    if (Array.isArray(body) && body[0]) {
      body[0].onboarding = {
        ...(body[0].onboarding ?? {}),
        signup_form_pending: !!state.signupFormPending,
        onboarding_flow_pending: !!state.onboardingFlowPending,
      };
      body[0].settings = { ...(body[0].settings ?? {}) };
      if (agentNetworkOnly === undefined) {
        delete body[0].settings.agent_network_only;
      } else {
        body[0].settings.agent_network_only = agentNetworkOnly;
      }
    }
    return route.fulfill({ response, json: body });
  });

  page.route("**/api/accounts/*", async (route) => {
    if (route.request().method() !== "PUT") return route.continue();
    agentNetworkOnly = true;
    return route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({ settings: { agent_network_only: true } }),
    });
  });
}

async function openOnboarding(
  browser: Browser,
  opts: {
    source?: boolean;
    account: AccountState;
    delayMs?: number;
    edition?: string;
    expectOnboarding?: boolean;
  },
): Promise<{ page: Page; close: () => Promise<void> }> {
  const context = await browser.newContext({
    storageState: "e2e/fixtures/auth/owner.json",
  });
  await context.addInitScript(
    ([sourceKey, sourceValue, withSource, edition]) => {
      try {
        window.localStorage.setItem("wardenclyffe-test-onboarding", "true");
        if (withSource) {
          window.localStorage.setItem(
            sourceKey as string,
            sourceValue as string,
          );
        }
        if (edition) {
          window.localStorage.setItem("wardenclyffe-test-edition", edition as string);
        }
      } catch (e) {}
    },
    [
      SIGNUP_SOURCE_KEY,
      AGENT_NETWORK_SOURCE,
      !!opts.source,
      opts.edition ?? "",
    ] as const,
  );
  const page = await context.newPage();
  mockAccounts(page, opts.account, opts.delayMs ?? 0);
  // The mocked GET /accounts is what drives the onboarding decision, and the
  // dashboard can resolve before it lands — a "no form opened" assertion would
  // then pass vacuously. Wait for the rewritten response before returning.
  const accountsLoaded = page.waitForResponse(
    (resp) =>
      /\/api\/accounts(\?|$)/.test(resp.url()) &&
      resp.request().method() === "GET",
  );
  await loginToApp(page, "owner", {
    expectOnboarding: opts.expectOnboarding ?? true,
  });
  await accountsLoaded;
  return { page, close: () => context.close() };
}

test.describe.serial("Onboarding form selection @onboarding", () => {
  test("wardenclyffe.ai signup shows the Agent Network form and never the regular one", async ({
    browser,
  }) => {
    const { page, close } = await openOnboarding(browser, {
      source: true,
      account: { signupFormPending: true, onboardingFlowPending: true },
    });
    try {
      await expect(page.getByTestId(AGENT_FORM)).toBeVisible();
      await expect(page.getByTestId(REGULAR_FORM)).toHaveCount(0);
    } finally {
      await close();
    }
  });

  test("a plain new cloud account shows the regular onboarding form", async ({
    browser,
  }) => {
    const { page, close } = await openOnboarding(browser, {
      source: false,
      account: { signupFormPending: true, onboardingFlowPending: true },
    });
    try {
      await expect(page.getByTestId(REGULAR_FORM)).toBeVisible();
      await expect(page.getByTestId(AGENT_FORM)).toHaveCount(0);
    } finally {
      await close();
    }
  });

  test("an account already marked agent_network_only shows the Agent Network form", async ({
    browser,
  }) => {
    const { page, close } = await openOnboarding(browser, {
      source: false,
      account: { onboardingFlowPending: true, agentNetworkOnly: true },
    });
    try {
      await expect(page.getByTestId(AGENT_FORM)).toBeVisible();
      await expect(page.getByTestId(REGULAR_FORM)).toHaveCount(0);
    } finally {
      await close();
    }
  });

  test("a self-hosted account with onboarding pending shows the regular flow at the intent step", async ({
    browser,
  }) => {
    const { page, close } = await openOnboarding(browser, {
      source: false,
      edition: "oss",
      account: { onboardingFlowPending: true },
    });
    try {
      await expect(page.getByTestId(REGULAR_FORM)).toBeVisible();
      await expect(page.getByTestId(AGENT_FORM)).toHaveCount(0);
      // The signup survey relies on a JWT domain claim self-hosted IdPs don't
      // emit, so the flow skips it and opens on the intent step. Scoped to the
      // form: the dashboard behind the modal has its own "Get Started with
      // WardenClyffe" heading, and getByText matches case-insensitively.
      await expect(
        page
          .getByTestId(REGULAR_FORM)
          .getByRole("heading", { name: "Get started with WardenClyffe" }),
      ).toBeVisible();
    } finally {
      await close();
    }
  });

  test("a self-hosted account with only the signup form pending shows no onboarding", async ({
    browser,
  }) => {
    const { page, close } = await openOnboarding(browser, {
      source: false,
      edition: "oss",
      account: { signupFormPending: true },
      expectOnboarding: false,
    });
    try {
      // loginToApp resolved the dashboard, so the account state has been
      // applied — neither flow should have opened.
      await expect(page.getByTestId(REGULAR_FORM)).toHaveCount(0);
      await expect(page.getByTestId(AGENT_FORM)).toHaveCount(0);
    } finally {
      await close();
    }
  });

  test("a slow backend never flashes the regular form for a wardenclyffe.ai signup", async ({
    browser,
  }) => {
    const { page, close } = await openOnboarding(browser, {
      source: true,
      account: { signupFormPending: true, onboardingFlowPending: true },
      delayMs: 1500,
    });
    try {
      // While /accounts is still loading, no onboarding form should have been
      // committed to the wrong flow.
      await expect(page.getByTestId(REGULAR_FORM)).toHaveCount(0);
      // Once it resolves, the Agent Network form is the one that appears...
      await expect(page.getByTestId(AGENT_FORM)).toBeVisible();
      await expect(page.getByTestId(REGULAR_FORM)).toHaveCount(0);
      // ...and it persists after the setting is applied (no flip/close).
      await page.waitForTimeout(1500);
      await expect(page.getByTestId(AGENT_FORM)).toBeVisible();
      await expect(page.getByTestId(REGULAR_FORM)).toHaveCount(0);
    } finally {
      await close();
    }
  });
});
