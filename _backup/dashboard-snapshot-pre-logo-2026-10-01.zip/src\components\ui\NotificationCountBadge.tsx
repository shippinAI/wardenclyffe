import { cn } from "@utils/helpers";
import * as React from "react";

type Props = {
  count?: number;
};
export const NotificationCountBadge = ({ count = 0 }: Props) => {
  return count ? (
    <div
      className={cn(
        count <= 9 ? "w-4 h-4" : "py-2 px-1.5",
        "relative bg-wardenclyffe flex items-center justify-center rounded-full text-white  !leading-[0]  text-[0.6rem] font-semibold",
      )}
    >
      <span className="animate-ping absolute left-0 inline-flex h-full w-full rounded-full bg-wardenclyffe opacity-20"></span>
      <span className={"relative -left-[0.5px]"}>{count || 0}</span>
    </div>
  ) : null;
};
